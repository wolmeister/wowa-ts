### 1.1.22
- Version Update

### 1.1.21
- Fix Error

### 1.1.20
- Version Update

### 1.1.19
- Version Update

### 1.1.18
- Fix C_UnitAuras error on classic

### 1.1.17
- Allow Fishing when in Zen flight

### 1.1.16
- Version update

### 1.1.15
- Add support for classic

### 1.1.14
- Version update

### 1.1.13
- Fixed cvars not being correctly restored on logout

### 1.1.12
- Version update

### 1.1.11
- Fixed Enhanced Sound not getting properly reset when ice fishing.
- Added option to allow recasting fishing for double click

### 1.1.10
- Patch 10.0.5 update

### 1.1.9
- Currently Keybind range on Wrath for bobber is limited on Blizzards side, you have to use your mouse to hook if keybind fails.
- Double Click to cast works now on all classes in wrath

### 1.1.8
- Wrath support

### 1.1.7
- Option to allow Fishing while the Looking for Lunkers buff is active.
- Partial ice fishing support, you can not use key to interact with fishing hole but you can use the bound key to hook.

### 1.1.6
- Shouldn't break the 'looking for lunkers' spell anymore.

### 1.1.5
- Fix error with double click to cast
- Add Option to disable icon above bobber (mostly only works with default ui anyway)

### 1.1.4
- Added basic Settings UI to enable/disable options, can be found under Options > AddOns > Better Fishing can also be accessed via /bf or /betterfishing
- Enhance Sound when fishing option has been added, adjust slider loudness in options when enabling. Will disable everything except SFX/Master.

### 1.1.3
- Double Click to cast is disabled by default now, enable it under /bf or /betterfishing
- keybinding header has it's own category again under Better Fishing
- Fishing key will work even if mounted now, restriction are only applied to the following:
  1. When looting, so you don't lose loot by spamming the key accidently
  2. When Flying, so you don't accidently kill yourself hitting the key mid flying, cause that can happen if you got pets or just because

Did you know? You can use controller bindings to fish
/console GamePadEnable 1 to enable gamepad mode
/console GamePadEnable 0 to disable gamepad mode again
in the keybinding ui you can then bind your controller key, and use that to fish with, sit back and relax
use the fantastic ConsolePort addon if you want a controller optimized UI